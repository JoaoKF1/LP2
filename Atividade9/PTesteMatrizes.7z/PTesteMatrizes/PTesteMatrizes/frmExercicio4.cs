﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTesteMatrizes
{
    public partial class frmExercicio4 : Form
    {
        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void btnCarregarNomesValores_Click(object sender, EventArgs e)
        {
            int[] valoresNomes = new int[5];
            string[] nomes = new string[30];

            for (int i = 0; i < 5; i++)
            {
                string nomeCompleto = Interaction.InputBox("Digite o nome completo da pessoa" +
                    (i + 1), "inputBox");
                nomes[i] = nomeCompleto;
                int tamanhoNome = nomeCompleto.Replace(" ", "").Length;
                valoresNomes[i] += tamanhoNome;
            }
            for (int i = 0;i < 5;i++)
            {
                listBoxNomesValores.Items.Add(nomes[i] + " - " + valoresNomes[i]);
            }
        }
    }
}
