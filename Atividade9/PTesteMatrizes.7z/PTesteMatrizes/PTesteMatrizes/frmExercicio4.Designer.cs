﻿namespace PTesteMatrizes
{
    partial class frmExercicio4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.listBoxNomesValores = new System.Windows.Forms.ListBox();
            this.btnCarregarNomesValores = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // listBoxNomesValores
            // 
            this.listBoxNomesValores.FormattingEnabled = true;
            this.listBoxNomesValores.ItemHeight = 20;
            this.listBoxNomesValores.Location = new System.Drawing.Point(185, 155);
            this.listBoxNomesValores.Name = "listBoxNomesValores";
            this.listBoxNomesValores.Size = new System.Drawing.Size(179, 204);
            this.listBoxNomesValores.TabIndex = 0;
            // 
            // btnCarregarNomesValores
            // 
            this.btnCarregarNomesValores.Location = new System.Drawing.Point(185, 397);
            this.btnCarregarNomesValores.Name = "btnCarregarNomesValores";
            this.btnCarregarNomesValores.Size = new System.Drawing.Size(179, 55);
            this.btnCarregarNomesValores.TabIndex = 1;
            this.btnCarregarNomesValores.Text = "Carregar nomes e valores";
            this.btnCarregarNomesValores.UseVisualStyleBackColor = true;
            this.btnCarregarNomesValores.Click += new System.EventHandler(this.btnCarregarNomesValores_Click);
            // 
            // frmExercicio4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1063, 598);
            this.Controls.Add(this.btnCarregarNomesValores);
            this.Controls.Add(this.listBoxNomesValores);
            this.Name = "frmExercicio4";
            this.Text = "frmExercicio4";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ListBox listBoxNomesValores;
        private System.Windows.Forms.Button btnCarregarNomesValores;
    }
}