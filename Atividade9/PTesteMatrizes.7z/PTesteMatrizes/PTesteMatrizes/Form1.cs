﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PTesteMatrizes
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnExercicio1_Click(object sender, EventArgs e)
        {
            int[] vetor = new int[20];
            string auxiliar;

            for (int i = 0; i < vetor.Length; i++)
            {
                auxiliar = Interaction.InputBox($"Digite o {i+1}º", "Entrada de dados");
                if (!int.TryParse(auxiliar, out vetor[i]))
                {
                    MessageBox.Show("Insira valor válido");
                    i--;
                }
            }
            Array.Reverse(vetor);
            auxiliar = "";
            foreach (int x in vetor)
                auxiliar += x + "\n";

            MessageBox.Show(auxiliar);
        }

        private void btnExercicio2_Click(object sender, EventArgs e)
        {
            ArrayList nomes = new ArrayList() { "Ana", "André", "Débora", "Fátima", 
                "João", "Janete", "Otávio", "Marcelo", "Pedro", "Thais" };
            string auxiliar;
            nomes.Remove("Otávio");
            auxiliar = "";

           
            foreach (string z in nomes)
                auxiliar += z + ',';
            
            MessageBox.Show(auxiliar);
        }

        private void btnExercicio3_Click(object sender, EventArgs e)
        {
            double[,] notas = new double[20, 3];

            for (int i = 0; i < 20; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    string input = Microsoft.VisualBasic.Interaction.InputBox($"Digite a nota {j + 1} do aluno {i + 1}:");
                    notas[i, j] = Convert.ToDouble(input);
                }
            }
            string mensagem = "";
            for (int i = 0; i < 20; i++)
            {
                double media = (notas[i, 0] + notas[i, 1] + notas[i, 2]) / 3;
                mensagem += $"Aluno {i + 1}: Média: {media.ToString("F1")}\n";
            }
            MessageBox.Show(mensagem, "Média dos alunos");
        }

        private void btnExercicio4_Click(object sender, EventArgs e)
        {
            frmExercicio4 frmExercicio4 = new frmExercicio4();
            frmExercicio4.ShowDialog();
        }

        private void btnExercicio5_Click(object sender, EventArgs e)
        {
            frmExercicio5 frmExercicio5 = new frmExercicio5();
            frmExercicio5.ShowDialog();
        }
    }
}
