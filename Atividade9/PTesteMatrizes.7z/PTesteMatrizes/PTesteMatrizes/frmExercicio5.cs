﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTesteMatrizes
{
    public partial class frmExercicio5 : Form
    {
        public frmExercicio5()
        {
            InitializeComponent();
        }

        private void btnCompararRespostas_Click(object sender, EventArgs e)
        {
            char[] gabarito = { 'A', 'B', 'C', 'D', 'E', 'A', 'B', 'C', 'D', 'E' };
            char[,] respostasAlunos = new char[5, 10];

            for (int i = 0; i < 5; i++)
            {
                for (int j = 0; j < 10; j++)
                {
                    string resposta = Interaction.InputBox("Digite a resposta da questão " +
                        (j + 1) + " do aluno " + (i + 1), "InputBox");
                    if (resposta.Length == 1 && "ABCDE".Contains(resposta.ToUpper()))
                    {
                        respostasAlunos[i , j] = char.ToUpper(resposta[0]);
                    }
                    else
                    {
                        MessageBox.Show("Resposta inválida! Digite A, B , C, D, E.", "Erro");
                        return;
                    }
                }
            }
            for (int i = 0; i < 5; i++)
            {
                int pontuacao = 0;
                for(int j = 0;j < 10; j++)
                {
                    if (respostasAlunos[i, j] == gabarito[j])
                    {
                        pontuacao++;
                    }
                }
                listBoxRespostasAlunos.Items.Add("Aluno " + (i + 1) + ": " + pontuacao + "acertos");
            }
        }
    }
}
